# Docker setup – Fun Club Event Management

This guide runs the ASP.NET Core 8 application and SQL Server 2022 in separate containers.

## Prerequisites
- Docker Desktop (Windows/Mac) or Docker Engine + Docker Compose plugin (Linux)
- At least 4 GB RAM available to Docker
- Ports `8080` and `1433` available

## Start the application

From the folder containing `docker-compose.yml`:

**PowerShell**
```powershell
Copy-Item .env.example .env
# Edit .env and set SA_PASSWORD to a strong password (8+ characters,
# upper/lower case, a number and a symbol).
docker compose up --build -d
docker compose ps
```

**macOS / Linux**
```bash
cp .env.example .env
# Edit .env and set a strong SA_PASSWORD.
docker compose up --build -d
docker compose ps
```

Open **http://localhost:8080** for the Fun Club C# Razor Pages web application and
**http://localhost:8080/swagger** for the API documentation (Development environment).

The first application start creates the database schema with EF Core `EnsureCreated()`.
The SQL Server data is persisted in the `funclub_sql_data` Docker volume.

## Useful commands

```bash
docker compose logs -f web       # Application logs
docker compose logs -f db        # SQL Server logs
docker compose restart web       # Restart the web app
docker compose down              # Stop and remove containers/network
docker compose down -v           # ALSO delete the database volume and its data
```

## Login and role menus
1. Open `http://localhost:8080`.
2. Create an account and select Participant or Organiser.
3. Log in with that account.
4. Organisers see Dashboard and My events. Participants see Events, My enrolments and My results.
5. Use Log out to clear the server-side session.

For a coursework demonstration, create a separate test account for each role. Do not use real personal passwords.

## Run tests outside Docker

Install the .NET 8 SDK, then run:
```bash
dotnet restore EventManagementApi.sln
dotnet build EventManagementApi.sln --configuration Release
dotnet test EventManagementApi.sln --configuration Release
```

## Troubleshooting
- **Database container is unhealthy:** check `docker compose logs db`, verify `.env` password complexity and confirm port 1433 is free.
- **Web app cannot connect:** wait for SQL Server health check, then run `docker compose restart web`.
- **Port already in use:** change the left side of the port mapping, e.g. `8081:8080`, and browse to `http://localhost:8081`.
- **Reset coursework database:** `docker compose down -v` removes the database volume. This is destructive.
- **Swagger unavailable:** ensure the app is running with `ASPNETCORE_ENVIRONMENT=Development`.

## Security notes
The Compose configuration is intended for local coursework/demo use. Do not expose SQL Server or the Development Swagger UI publicly. Change the sample SA password, use HTTPS and production cookie settings, and restrict Organiser account creation before deploying to production.
