# Fun Club Event Management

ASP.NET Core 8 event management coursework project with SQL Server, EF Core, session-based authentication, C# Razor Pages and a REST API. The web interface is server-rendered in C# and contains no JavaScript client code.

## Features
- Registration and login for Participant and Organiser roles.
- Server-side session stores the authenticated user ID and role; logout clears the session.
- Role-specific navigation and protected page/API operations.
- Server-rendered C# Razor Pages interface; no JavaScript files or browser-side application logic.
- Organiser dashboard with event/category/enrolment/result totals.
- Organiser event create, read, update and delete.
- Category creation and deletion for organiser-owned events.
- View event enrolments and enter participant finish times and positions.
- Participant event browsing, category enrolment, own enrolments and own results.
- PBKDF2 password hashing, SQL Server persistence and Swagger API docs.
- Docker Compose deployment and GitHub Actions CI.

## Project structure
```text
.
├── .github/workflows/dotnet.yml
├── src/EventManagementApi/
│   ├── Controllers/       # REST endpoints and role checks
│   ├── Data/              # EF Core DbContext
│   ├── Models/            # User, event, category, enrolment, result
│   ├── Services/          # Password and current-session services
│   ├── Pages/             # C# Razor Pages and shared layout
│   └── wwwroot/           # CSS styling only
├── tests/EventManagementApi.Tests/
├── Dockerfile
├── docker-compose.yml
├── README_DOCKER.md
└── evidence/              # Add your own screenshots
```

## Run locally with .NET 8
1. Install .NET 8 SDK and SQL Server LocalDB or SQL Server.
2. Open `EventManagementApi.sln` in Visual Studio 2022 (17.8 or later, with the ASP.NET and web development workload). Update `src/EventManagementApi/appsettings.json` connection string if needed.
3. Run:
   ```bash
   dotnet restore EventManagementApi.sln
   dotnet run --project src/EventManagementApi
   ```
4. Browse to the URL printed by `dotnet run`. The user interface is implemented in C# Razor Pages. Swagger is available at `/swagger` in Development.

## Open in Visual Studio 2022
1. Extract the ZIP file.
2. Open `EventManagementApi.sln` in Visual Studio 2022 (17.8 or later).
3. Set `EventManagementApi` as the startup project.
4. Configure SQL Server in `appsettings.json`, or start the supplied Docker Compose database.
5. Press **F5** to build and run. The application opens on its Razor Pages home screen.
6. All web forms post to C# Razor Page handlers in `Pages/Index.cshtml.cs`; there is no `app.js` or JavaScript front end.

## Run with Docker
See **[README_DOCKER.md](README_DOCKER.md)**. The short version:
```bash
cp .env.example .env
# Edit .env and set a strong SA_PASSWORD
docker compose up --build -d
```
Open `http://localhost:8080`.

## CI workflow
`.github/workflows/dotnet.yml` runs on pushes and pull requests. It checks required project files/folders, restores NuGet packages, builds the solution in Release mode and runs the automated tests. A green workflow is evidence of a successful CI run; it does not replace a local functional demonstration.

## Git commit requirement (20+ meaningful commits)
Commit history must be created in your own Git repository over the development process. A ZIP file cannot prove that 20 separate, meaningful commits were made, and this project does not fabricate commit history. Use small, genuine commits as you complete and test features. Suggested commit sequence:
1. Create solution and API project
2. Add EF Core SQL Server package
3. Add user and role models
4. Add event model
5. Add category model
6. Add enrolment model
7. Add result model
8. Configure DbContext relationships
9. Add password hashing service
10. Add current-user session service
11. Add registration endpoint
12. Add login and logout endpoints
13. Add profile endpoints
14. Add event CRUD endpoints
15. Add category management endpoints
16. Add participant enrolment endpoints
17. Add result recording and privacy checks
18. Add organiser dashboard endpoint
19. Add role-aware web interface
20. Add organiser event/category/result screens
21. Add participant pages and navigation
22. Add Docker configuration and documentation
23. Add CI structure validation and tests

Example workflow:
```bash
git init
git add .
git commit -m "Create event management solution and project structure"
# After each subsequent feature/change:
git add .
git commit -m "Add organiser dashboard summary endpoint"
git push -u origin main
```
Do not make empty or duplicate commits just to reach the count. Push the repository to GitHub so the commit history and Actions run can be inspected.

## Evidence required for submission
- Capture genuine screenshots of registration/login, each role's navigation, organiser dashboard, event CRUD, category management, enrolment list and result entry, participant enrolment/results, and the green GitHub Actions run.
- Add your actual screenshot files to `evidence/screenshots/`. No screenshots are fabricated or included as if they were captured from a running application.

## API overview
| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Register Participant or Organiser |
| POST | `/api/auth/login` | Login and store user ID/role in session |
| POST | `/api/auth/logout` | Clear session |
| GET/PUT | `/api/users/me` | View/update own profile |
| GET | `/api/events` | List public events |
| GET | `/api/events/mine` | List current organiser's events |
| GET | `/api/events/{id}` | Event detail |
| POST | `/api/events` | Organiser creates event |
| PUT/DELETE | `/api/events/{id}` | Update/delete owned event |
| GET/POST | `/api/events/{eventId}/categories` | List/add categories |
| DELETE | `/api/events/{eventId}/categories/{categoryId}` | Delete category |
| POST | `/api/enrolments` | Participant enrols |
| GET | `/api/enrolments/mine` | Participant's enrolments |
| GET | `/api/enrolments/event/{eventId}` | Organiser views event enrolments |
| POST | `/api/results/enrolment/{enrolmentId}` | Organiser records a result |
| GET | `/api/results/event/{eventId}` | Organiser views event results |
| GET | `/api/results/mine` | Participant views own results |
| GET | `/api/organiser/dashboard` | Organiser dashboard totals |

## Tests
```bash
dotnet test EventManagementApi.sln --configuration Release
```

## Important notes
- This is a coursework/demo implementation. Restrict Organiser registration to an administrator/invitation before public deployment.
- Use HTTPS and production cookie settings in a real deployment. Do not expose the SQL Server port or Development Swagger publicly.
- `EnsureCreated()` is used for simple first-run coursework setup. For schema evolution, switch to EF Core migrations.
- Confirm the data model against your approved Part 1 ERD/SQL script before submission.
