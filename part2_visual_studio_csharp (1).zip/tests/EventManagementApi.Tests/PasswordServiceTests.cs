using EventManagementApi.Services;
using Xunit;

namespace EventManagementApi.Tests;

public class PasswordServiceTests
{
    [Fact]
    public void HashAndVerify_ValidPassword_ReturnsTrue()
    {
        var service = new PasswordService();
        var hash = service.Hash("CorrectHorseBattery9!");
        Assert.NotEqual("CorrectHorseBattery9!", hash);
        Assert.True(service.Verify("CorrectHorseBattery9!", hash));
    }

    [Fact]
    public void Verify_WrongPassword_ReturnsFalse()
    {
        var service = new PasswordService();
        var hash = service.Hash("CorrectHorseBattery9!");
        Assert.False(service.Verify("wrong-password", hash));
    }
}
