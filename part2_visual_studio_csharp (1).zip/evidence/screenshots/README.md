# Screenshot evidence

Save genuine screenshots captured from your running application in this folder. Suggested screenshots:

1. Participant registration and login.
2. Participant events list and event enrolment.
3. Participant enrolments and results.
4. Organiser dashboard.
5. Organiser event create/edit/delete screens.
6. Category management.
7. Enrolment list and result entry.
8. Successful GitHub Actions build and test run.

Do not add mock screenshots or claim screenshots were captured if they were not.
