using EventManagementApi.Models;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<EventCategory> Categories => Set<EventCategory>();
    public DbSet<EventEnrolment> Enrolments => Set<EventEnrolment>();
    public DbSet<EventResult> Results => Set<EventResult>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AppUser>().HasIndex(x => x.Email).IsUnique();
        modelBuilder.Entity<Event>().HasOne(x => x.Organiser)
            .WithMany().HasForeignKey(x => x.OrganiserId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<EventCategory>().HasOne(x => x.Event)
            .WithMany(x => x.Categories).HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<EventEnrolment>().HasIndex(x => new { x.ParticipantId, x.EventId }).IsUnique();
        modelBuilder.Entity<EventEnrolment>().HasOne(x => x.Participant)
            .WithMany().HasForeignKey(x => x.ParticipantId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<EventEnrolment>().HasOne(x => x.Event)
            .WithMany(x => x.Enrolments).HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<EventEnrolment>().HasOne(x => x.Category)
            .WithMany().HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<EventResult>().HasIndex(x => x.EnrolmentId).IsUnique();
        modelBuilder.Entity<EventResult>().HasOne(x => x.Enrolment)
            .WithOne().HasForeignKey<EventResult>(x => x.EnrolmentId).OnDelete(DeleteBehavior.Cascade);
    }
}
