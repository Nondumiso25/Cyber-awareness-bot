using EventManagementApi.Data;
using EventManagementApi.Models;
using EventManagementApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Controllers;

[ApiController, Route("api/events")]
public class EventsController(AppDbContext db, CurrentUserService current) : ControllerBase
{
    public record EventRequest(string Name, string Description, DateTime Date, string Location, decimal DistanceKm, EventType Type);
    public record CategoryRequest(string Name, string CategoryKind, int? MinimumAge, int? MaximumAge, decimal? DistanceKm);

    /// <summary>List events (public to both roles).</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok(await db.Events.Include(e => e.Categories)
        .Select(e => new { e.Id, e.Name, e.Description, e.Date, e.Location, e.DistanceKm, e.Type,
            Categories = e.Categories.Select(c => new { c.Id, c.Name, c.CategoryKind, c.MinimumAge, c.MaximumAge, c.DistanceKm }) })
        .ToListAsync());

    /// <summary>List events owned by the signed-in organiser.</summary>
    [HttpGet("mine")]
    public async Task<IActionResult> Mine()
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        return Ok(await db.Events.Where(e => e.OrganiserId == current.UserId)
            .Include(e => e.Categories)
            .Select(e => new { e.Id, e.Name, e.Description, e.Date, e.Location, e.DistanceKm, e.Type,
                Categories = e.Categories.Select(c => new { c.Id, c.Name, c.CategoryKind, c.MinimumAge, c.MaximumAge, c.DistanceKm }) })
            .ToListAsync());
    }

    /// <summary>Get one event and its categories.</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var e = await db.Events.Include(x => x.Categories).FirstOrDefaultAsync(x => x.Id == id);
        return e is null ? NotFound() : Ok(e);
    }

    /// <summary>Create an event. Organiser role required.</summary>
    [HttpPost, ProducesResponseType(StatusCodes.Status201Created)]
    public async Task<IActionResult> Create(EventRequest request)
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Location) || request.DistanceKm <= 0)
            return BadRequest(new { message = "Name, location and positive distance are required." });
        var e = new Event { Name = request.Name, Description = request.Description, Date = request.Date,
            Location = request.Location, DistanceKm = request.DistanceKm, Type = request.Type, OrganiserId = current.UserId!.Value };
        db.Events.Add(e); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = e.Id }, e);
    }

    /// <summary>Update an event owned by the current organiser.</summary>
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, EventRequest request)
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        var e = await db.Events.FirstOrDefaultAsync(x => x.Id == id);
        if (e is null) return NotFound();
        if (e.OrganiserId != current.UserId) return Forbid();
        e.Name = request.Name; e.Description = request.Description; e.Date = request.Date;
        e.Location = request.Location; e.DistanceKm = request.DistanceKm; e.Type = request.Type;
        await db.SaveChangesAsync(); return Ok(e);
    }

    /// <summary>Delete an event owned by the current organiser.</summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        var e = await db.Events.FirstOrDefaultAsync(x => x.Id == id);
        if (e is null) return NotFound();
        if (e.OrganiserId != current.UserId) return Forbid();
        db.Events.Remove(e); await db.SaveChangesAsync(); return NoContent();
    }

    /// <summary>List categories for an event.</summary>
    [HttpGet("{eventId:int}/categories")]
    public async Task<IActionResult> GetCategories(int eventId)
    {
        if (!await db.Events.AnyAsync(e => e.Id == eventId)) return NotFound();
        return Ok(await db.Categories.Where(c => c.EventId == eventId).ToListAsync());
    }

    /// <summary>Create an event category. Organiser who owns event required.</summary>
    [HttpPost("{eventId:int}/categories")]
    public async Task<IActionResult> AddCategory(int eventId, CategoryRequest request)
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        var e = await db.Events.FirstOrDefaultAsync(x => x.Id == eventId);
        if (e is null) return NotFound();
        if (e.OrganiserId != current.UserId) return Forbid();
        if (string.IsNullOrWhiteSpace(request.Name)) return BadRequest(new { message = "Category name is required." });
        var c = new EventCategory { EventId = eventId, Name = request.Name, CategoryKind = request.CategoryKind,
            MinimumAge = request.MinimumAge, MaximumAge = request.MaximumAge, DistanceKm = request.DistanceKm };
        db.Categories.Add(c); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetCategories), new { eventId }, c);
    }

    /// <summary>Delete a category belonging to an event owned by the organiser.</summary>
    [HttpDelete("{eventId:int}/categories/{categoryId:int}")]
    public async Task<IActionResult> DeleteCategory(int eventId, int categoryId)
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        var c = await db.Categories.Include(x => x.Event).FirstOrDefaultAsync(x => x.Id == categoryId && x.EventId == eventId);
        if (c is null) return NotFound();
        if (c.Event?.OrganiserId != current.UserId) return Forbid();
        db.Categories.Remove(c); await db.SaveChangesAsync(); return NoContent();
    }
}
