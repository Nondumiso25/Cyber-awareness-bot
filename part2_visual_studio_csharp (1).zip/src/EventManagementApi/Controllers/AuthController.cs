using EventManagementApi.Data;
using EventManagementApi.Models;
using EventManagementApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Controllers;

[ApiController, Route("api/auth")]
public class AuthController(AppDbContext db, PasswordService passwords) : ControllerBase
{
    public record RegisterRequest(string FullName, string Email, string Password, UserRole Role, string? Phone);
    public record LoginRequest(string Email, string Password);

    /// <summary>Register a participant or organiser. In production, restrict organiser creation to an administrator/invitation.</summary>
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.FullName) || string.IsNullOrWhiteSpace(request.Email) ||
            request.Password.Length < 8 || !Enum.IsDefined(request.Role))
            return BadRequest(new { message = "Name/email are required, password must be at least 8 characters, and role must be valid." });
        var email = request.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(x => x.Email == email)) return Conflict(new { message = "Email already registered." });
        var user = new AppUser { FullName = request.FullName.Trim(), Email = email,
            PasswordHash = passwords.Hash(request.Password), Role = request.Role, Phone = request.Phone };
        db.Users.Add(user);
        await db.SaveChangesAsync();
        return Created($"/api/users/me", new { user.Id, user.FullName, user.Email, user.Role });
    }

    /// <summary>Log in and create a server-side session.</summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var user = await db.Users.FirstOrDefaultAsync(x => x.Email == request.Email.Trim().ToLowerInvariant());
        if (user is null || !passwords.Verify(request.Password, user.PasswordHash))
            return Unauthorized(new { message = "Invalid email or password." });
        HttpContext.Session.SetInt32("UserId", user.Id);
        HttpContext.Session.SetString("Role", user.Role.ToString());
        return Ok(new { user.Id, user.FullName, user.Email, user.Role });
    }

    /// <summary>Log out the current session.</summary>
    [HttpPost("logout")]
    public IActionResult Logout() { HttpContext.Session.Clear(); return Ok(new { message = "Logged out." }); }
}
