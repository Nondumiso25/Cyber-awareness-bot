using EventManagementApi.Data;
using EventManagementApi.Models;
using EventManagementApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Controllers;

[ApiController, Route("api/organiser")]
public class OrganiserController(AppDbContext db, CurrentUserService current) : ControllerBase
{
    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard()
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        var events = db.Events.Where(e => e.OrganiserId == current.UserId);
        var eventIds = events.Select(e => e.Id);
        var enrolments = db.Enrolments.Where(e => eventIds.Contains(e.EventId));
        var enrolmentIds = enrolments.Select(e => e.Id);
        return Ok(new {
            Events = await events.CountAsync(),
            Categories = await db.Categories.Where(c => eventIds.Contains(c.EventId)).CountAsync(),
            Enrolments = await enrolments.CountAsync(),
            Results = await db.Results.Where(r => enrolmentIds.Contains(r.EnrolmentId)).CountAsync()
        });
    }
}
