using EventManagementApi.Data;
using EventManagementApi.Models;
using EventManagementApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Controllers;

[ApiController, Route("api/enrolments")]
public class EnrolmentsController(AppDbContext db, CurrentUserService current) : ControllerBase
{
    public record EnrolRequest(int EventId, int CategoryId);

    /// <summary>Participant enrols in an event using one of its categories.</summary>
    [HttpPost]
    public async Task<IActionResult> Enrol(EnrolRequest request)
    {
        if (current.Role != UserRole.Participant) return current.IsAuthenticated ? Forbid() : Unauthorized();
        var category = await db.Categories.FirstOrDefaultAsync(c => c.Id == request.CategoryId && c.EventId == request.EventId);
        if (category is null) return BadRequest(new { message = "Category does not belong to the selected event." });
        if (await db.Enrolments.AnyAsync(x => x.ParticipantId == current.UserId && x.EventId == request.EventId))
            return Conflict(new { message = "You are already enrolled in this event." });
        var enrolment = new EventEnrolment { ParticipantId = current.UserId!.Value, EventId = request.EventId, CategoryId = request.CategoryId };
        db.Enrolments.Add(enrolment); await db.SaveChangesAsync();
        return Created($"/api/enrolments/mine", new { enrolment.Id, enrolment.EventId, enrolment.CategoryId, enrolment.EnrolledAt });
    }

    /// <summary>Participant views own enrolments.</summary>
    [HttpGet("mine")]
    public async Task<IActionResult> Mine()
    {
        if (current.Role != UserRole.Participant) return current.IsAuthenticated ? Forbid() : Unauthorized();
        return Ok(await db.Enrolments.Where(x => x.ParticipantId == current.UserId)
            .Include(x => x.Event).Include(x => x.Category)
            .Select(x => new { x.Id, x.EventId, EventName = x.Event!.Name, x.CategoryId, CategoryName = x.Category!.Name, x.EnrolledAt })
            .ToListAsync());
    }

    /// <summary>Organiser views enrolments for their own event.</summary>
    [HttpGet("event/{eventId:int}")]
    public async Task<IActionResult> ForEvent(int eventId)
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        var e = await db.Events.FirstOrDefaultAsync(x => x.Id == eventId);
        if (e is null) return NotFound();
        if (e.OrganiserId != current.UserId) return Forbid();
        return Ok(await db.Enrolments.Where(x => x.EventId == eventId).Include(x => x.Participant).Include(x => x.Category)
            .Select(x => new { x.Id, ParticipantId = x.ParticipantId, ParticipantName = x.Participant!.FullName,
                x.CategoryId, CategoryName = x.Category!.Name, x.EnrolledAt }).ToListAsync());
    }
}
