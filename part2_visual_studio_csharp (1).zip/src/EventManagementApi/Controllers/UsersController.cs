using EventManagementApi.Data;
using EventManagementApi.Models;
using EventManagementApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementApi.Controllers;

[ApiController, Route("api/users")]
public class UsersController(AppDbContext db, CurrentUserService current, PasswordService passwords) : ControllerBase
{
    public record UpdateProfileRequest(string FullName, string? Phone, string? NewPassword);

    /// <summary>View the currently authenticated user's own profile.</summary>
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var user = await current.GetUserAsync();
        if (user is null) return Unauthorized();
        return Ok(new { user.Id, user.FullName, user.Email, user.Role, user.Phone });
    }

    /// <summary>Update own profile only; role and email cannot be changed here.</summary>
    [HttpPut("me")]
    public async Task<IActionResult> Update(UpdateProfileRequest request)
    {
        var user = await current.GetUserAsync();
        if (user is null) return Unauthorized();
        if (string.IsNullOrWhiteSpace(request.FullName)) return BadRequest(new { message = "Full name is required." });
        user.FullName = request.FullName.Trim();
        user.Phone = request.Phone;
        if (!string.IsNullOrWhiteSpace(request.NewPassword))
        {
            if (request.NewPassword.Length < 8) return BadRequest(new { message = "Password must be at least 8 characters." });
            user.PasswordHash = passwords.Hash(request.NewPassword);
        }
        await db.SaveChangesAsync();
        return Ok(new { user.Id, user.FullName, user.Email, user.Role, user.Phone });
    }
}
