using EventManagementApi.Data;
using EventManagementApi.Models;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Services;

public class CurrentUserService(IHttpContextAccessor accessor, AppDbContext db)
{
    public int? UserId => accessor.HttpContext?.Session.GetInt32("UserId");
    public UserRole? Role
    {
        get
        {
            var role = accessor.HttpContext?.Session.GetString("Role");
            return Enum.TryParse<UserRole>(role, out var parsed) ? parsed : null;
        }
    }
    public bool IsAuthenticated => UserId.HasValue;
    public async Task<AppUser?> GetUserAsync() =>
        UserId is int id ? await db.Users.FirstOrDefaultAsync(x => x.Id == id) : null;
}
