using EventManagementApi.Data;
using EventManagementApi.Models;
using EventManagementApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace EventManagementApi.Pages;

public class IndexModel(AppDbContext db, CurrentUserService current, PasswordService passwords) : PageModel
{
    public AppUser? CurrentUser { get; private set; }
    public string ViewName { get; private set; } = "events";
    public List<Event> Events { get; private set; } = [];
    public List<EventEnrolment> Enrolments { get; private set; } = [];
    public List<EventResult> Results { get; private set; } = [];
    public int EventCount { get; private set; }
    public int CategoryCount { get; private set; }
    public int EnrolmentCount { get; private set; }
    public int ResultCount { get; private set; }

    [BindProperty] public RegisterInput Register { get; set; } = new();
    [BindProperty] public LoginInput Login { get; set; } = new();
    [BindProperty] public EventInput EventForm { get; set; } = new();
    [BindProperty] public CategoryInput CategoryForm { get; set; } = new();
    [BindProperty] public int EventId { get; set; }
    [BindProperty] public int CategoryId { get; set; }
    [BindProperty] public int EnrolmentId { get; set; }
    [BindProperty] public string FinishTime { get; set; } = "";
    [BindProperty] public int FinishPosition { get; set; }

    public record RegisterInput
    {
        [Required, StringLength(120)] public string FullName { get; set; } = "";
        [Required, EmailAddress, StringLength(180)] public string Email { get; set; } = "";
        [Required, MinLength(8)] public string Password { get; set; } = "";
        public UserRole Role { get; set; } = UserRole.Participant;
        [StringLength(40)] public string? Phone { get; set; }
    }
    public record LoginInput
    {
        [Required, EmailAddress] public string Email { get; set; } = "";
        [Required] public string Password { get; set; } = "";
    }
    public record EventInput
    {
        public int? Id { get; set; }
        [Required, StringLength(150)] public string Name { get; set; } = "";
        [StringLength(2000)] public string Description { get; set; } = "";
        [Required] public DateTime Date { get; set; } = DateTime.Now.AddDays(7);
        [Required, StringLength(200)] public string Location { get; set; } = "";
        [Range(typeof(decimal), "0.01", "999999")] public decimal DistanceKm { get; set; }
        public EventType Type { get; set; } = EventType.Run;
    }
    public record CategoryInput
    {
        [Required, StringLength(100)] public string Name { get; set; } = "";
        [StringLength(30)] public string CategoryKind { get; set; } = "Age";
        public int? MinimumAge { get; set; }
        public int? MaximumAge { get; set; }
        public decimal? DistanceKm { get; set; }
    }

    public async Task OnGetAsync(string view = "events")
    {
        CurrentUser = await current.GetUserAsync();
        ViewName = view;
        if (CurrentUser == null) { ViewName = "login"; return; }
        if (CurrentUser.Role == UserRole.Organiser)
        {
            if (ViewName is not ("dashboard" or "events")) ViewName = "dashboard";
            var owned = db.Events.Where(e => e.OrganiserId == CurrentUser.Id);
            var ids = owned.Select(e => e.Id);
            EventCount = await owned.CountAsync();
            CategoryCount = await db.Categories.CountAsync(c => ids.Contains(c.EventId));
            EnrolmentCount = await db.Enrolments.CountAsync(e => ids.Contains(e.EventId));
            ResultCount = await db.Results.CountAsync(r => db.Enrolments.Where(e => ids.Contains(e.EventId)).Select(e => e.Id).Contains(r.EnrolmentId));
            if (ViewName == "events") Events = await owned.Include(e => e.Categories).OrderBy(e => e.Date).ToListAsync();
        }
        else
        {
            if (ViewName is not ("events" or "enrolments" or "results")) ViewName = "events";
            if (ViewName == "events") Events = await db.Events.Include(e => e.Categories).OrderBy(e => e.Date).ToListAsync();
            if (ViewName == "enrolments") Enrolments = await db.Enrolments.Include(e => e.Event).Include(e => e.Category).Where(e => e.ParticipantId == CurrentUser.Id).OrderByDescending(e => e.EnrolledAt).ToListAsync();
            if (ViewName == "results") Results = await db.Results.Include(r => r.Enrolment).ThenInclude(e => e!.Event).Where(r => r.Enrolment!.ParticipantId == CurrentUser.Id).OrderBy(r => r.FinishPosition).ToListAsync();
        }
    }

    public async Task<IActionResult> OnPostRegisterAsync()
    {
        if (!ModelState.IsValid) { await OnGetAsync("login"); ViewName = "register"; return Page(); }
        var email = Register.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(u => u.Email == email)) { TempData["Error"] = "That email address is already registered."; return RedirectToPage(); }
        db.Users.Add(new AppUser { FullName = Register.FullName.Trim(), Email = email, PasswordHash = passwords.Hash(Register.Password), Role = Register.Role, Phone = Register.Phone });
        await db.SaveChangesAsync();
        TempData["Message"] = "Account created. Please log in.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostLoginAsync()
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.Email == Login.Email.Trim().ToLowerInvariant());
        if (user == null || !passwords.Verify(Login.Password, user.PasswordHash))
        { TempData["Error"] = "Invalid email address or password."; return RedirectToPage(); }
        HttpContext.Session.SetInt32("UserId", user.Id);
        HttpContext.Session.SetString("Role", user.Role.ToString());
        return RedirectToPage(new { view = user.Role == UserRole.Organiser ? "dashboard" : "events" });
    }

    public IActionResult OnPostLogout()
    {
        HttpContext.Session.Clear();
        TempData["Message"] = "You have been logged out.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostSaveEventAsync()
    {
        if (!await RequireRole(UserRole.Organiser)) return Forbid();
        if (!ModelState.IsValid) { TempData["Error"] = "Please complete all required event fields."; return RedirectToPage(new { view = "events" }); }
        Event entity;
        if (EventForm.Id.HasValue)
        {
            entity = await db.Events.FirstOrDefaultAsync(e => e.Id == EventForm.Id && e.OrganiserId == current.UserId) ?? null!;
            if (entity == null) return NotFound();
        }
        else { entity = new Event { OrganiserId = current.UserId!.Value }; db.Events.Add(entity); }
        entity.Name = EventForm.Name.Trim(); entity.Description = EventForm.Description; entity.Date = EventForm.Date;
        entity.Location = EventForm.Location.Trim(); entity.DistanceKm = EventForm.DistanceKm; entity.Type = EventForm.Type;
        await db.SaveChangesAsync(); TempData["Message"] = "Event saved.";
        return RedirectToPage(new { view = "events" });
    }

    public async Task<IActionResult> OnPostDeleteEventAsync(int id)
    {
        if (!await RequireRole(UserRole.Organiser)) return Forbid();
        var entity = await db.Events.FirstOrDefaultAsync(e => e.Id == id && e.OrganiserId == current.UserId);
        if (entity == null) return NotFound();
        db.Events.Remove(entity); await db.SaveChangesAsync(); TempData["Message"] = "Event deleted.";
        return RedirectToPage(new { view = "events" });
    }

    public async Task<IActionResult> OnPostAddCategoryAsync()
    {
        if (!await RequireRole(UserRole.Organiser)) return Forbid();
        var entity = await db.Events.FirstOrDefaultAsync(e => e.Id == EventId && e.OrganiserId == current.UserId);
        if (entity == null) return NotFound();
        if (!TryValidateModel(CategoryForm)) return RedirectToPage(new { view = "events" });
        db.Categories.Add(new EventCategory { EventId = EventId, Name = CategoryForm.Name.Trim(), CategoryKind = CategoryForm.CategoryKind, MinimumAge = CategoryForm.MinimumAge, MaximumAge = CategoryForm.MaximumAge, DistanceKm = CategoryForm.DistanceKm });
        await db.SaveChangesAsync(); TempData["Message"] = "Category added.";
        return RedirectToPage(new { view = "events" });
    }

    public async Task<IActionResult> OnPostDeleteCategoryAsync(int id)
    {
        if (!await RequireRole(UserRole.Organiser)) return Forbid();
        var category = await db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.Id == id && c.Event!.OrganiserId == current.UserId);
        if (category == null) return NotFound();
        if (await db.Enrolments.AnyAsync(e => e.CategoryId == id)) { TempData["Error"] = "A category with enrolments cannot be removed."; return RedirectToPage(new { view = "events" }); }
        db.Categories.Remove(category); await db.SaveChangesAsync(); TempData["Message"] = "Category removed.";
        return RedirectToPage(new { view = "events" });
    }

    public async Task<IActionResult> OnPostEnrolAsync()
    {
        if (!await RequireRole(UserRole.Participant)) return Forbid();
        var category = await db.Categories.FirstOrDefaultAsync(c => c.Id == CategoryId && c.EventId == EventId);
        if (category == null) return NotFound();
        if (await db.Enrolments.AnyAsync(e => e.EventId == EventId && e.ParticipantId == current.UserId))
            TempData["Error"] = "You are already enrolled in this event.";
        else
        {
            db.Enrolments.Add(new EventEnrolment { EventId = EventId, CategoryId = CategoryId, ParticipantId = current.UserId!.Value });
            await db.SaveChangesAsync(); TempData["Message"] = "You have enrolled successfully.";
        }
        return RedirectToPage(new { view = "events" });
    }

    public async Task<IActionResult> OnPostRecordResultAsync()
    {
        if (!await RequireRole(UserRole.Organiser)) return Forbid();
        var enrolment = await db.Enrolments.Include(e => e.Event).FirstOrDefaultAsync(e => e.Id == EnrolmentId && e.Event!.OrganiserId == current.UserId);
        if (enrolment == null) return NotFound();
        if (!TimeSpan.TryParse(FinishTime, out var time) || time <= TimeSpan.Zero || FinishPosition < 1)
        { TempData["Error"] = "Enter a valid finish time and positive position."; return RedirectToPage(new { view = "events" }); }
        if (await db.Results.AnyAsync(r => r.EnrolmentId == EnrolmentId)) { TempData["Error"] = "A result has already been recorded for this enrolment."; return RedirectToPage(new { view = "events" }); }
        db.Results.Add(new EventResult { EnrolmentId = EnrolmentId, FinishTime = time, FinishPosition = FinishPosition });
        await db.SaveChangesAsync(); TempData["Message"] = "Result recorded.";
        return RedirectToPage(new { view = "events" });
    }

    public async Task<List<EventEnrolment>> GetEventEnrolments(int eventId) => await db.Enrolments.Include(e => e.Participant).Include(e => e.Category).Include(e => e.Event).Where(e => e.EventId == eventId && e.Event!.OrganiserId == current.UserId).OrderBy(e => e.EnrolledAt).ToListAsync();
    public async Task<List<EventResult>> GetEventResults(int eventId) => await db.Results.Include(r => r.Enrolment).ThenInclude(e => e!.Participant).Where(r => r.Enrolment!.EventId == eventId && r.Enrolment.Event!.OrganiserId == current.UserId).OrderBy(r => r.FinishPosition).ToListAsync();
    private Task<bool> RequireRole(UserRole role) => Task.FromResult(current.Role == role && current.UserId.HasValue);
}
