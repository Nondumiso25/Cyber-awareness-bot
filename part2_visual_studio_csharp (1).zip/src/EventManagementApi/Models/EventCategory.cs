using System.ComponentModel.DataAnnotations;

namespace EventManagementApi.Models;

public class EventCategory
{
    public int Id { get; set; }
    public int EventId { get; set; }
    public Event? Event { get; set; }
    [Required, MaxLength(100)] public string Name { get; set; } = "";
    [MaxLength(30)] public string CategoryKind { get; set; } = "Age";
    public int? MinimumAge { get; set; }
    public int? MaximumAge { get; set; }
    public decimal? DistanceKm { get; set; }
}
