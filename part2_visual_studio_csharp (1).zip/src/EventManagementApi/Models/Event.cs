using System.ComponentModel.DataAnnotations;

namespace EventManagementApi.Models;

public class Event
{
    public int Id { get; set; }
    [Required, MaxLength(150)] public string Name { get; set; } = "";
    [MaxLength(2000)] public string Description { get; set; } = "";
    public DateTime Date { get; set; }
    [Required, MaxLength(200)] public string Location { get; set; } = "";
    public decimal DistanceKm { get; set; }
    [Required] public EventType Type { get; set; }
    public int OrganiserId { get; set; }
    public AppUser? Organiser { get; set; }
    public List<EventCategory> Categories { get; set; } = [];
    public List<EventEnrolment> Enrolments { get; set; } = [];
}
public enum EventType { Run = 1, Walk = 2, Cycle = 3 }
