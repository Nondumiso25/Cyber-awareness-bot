using System.ComponentModel.DataAnnotations;

namespace EventManagementApi.Models;

public class AppUser
{
    public int Id { get; set; }
    [Required, MaxLength(120)] public string FullName { get; set; } = "";
    [Required, EmailAddress, MaxLength(180)] public string Email { get; set; } = "";
    [Required] public string PasswordHash { get; set; } = "";
    [Required] public UserRole Role { get; set; }
    [MaxLength(40)] public string? Phone { get; set; }
}

public enum UserRole { Participant = 1, Organiser = 2 }
