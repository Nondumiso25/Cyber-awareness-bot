namespace EventManagementApi.Models;

public class EventEnrolment
{
    public int Id { get; set; }
    public int ParticipantId { get; set; }
    public AppUser? Participant { get; set; }
    public int EventId { get; set; }
    public Event? Event { get; set; }
    public int CategoryId { get; set; }
    public EventCategory? Category { get; set; }
    public DateTime EnrolledAt { get; set; } = DateTime.UtcNow;
}
