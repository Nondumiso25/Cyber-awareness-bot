using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace FunClub.Api.Infrastructure;
public static class SessionKeys { public const string UserId = "UserId"; public const string Role = "Role"; public const string Name = "Name"; }
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class SessionAuthorizeAttribute : Attribute, IAsyncActionFilter
{
    public string? RequiredRole { get; }
    public SessionAuthorizeAttribute(string? requiredRole = null) => RequiredRole = requiredRole;
    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var session = context.HttpContext.Session;
        var id = session.GetInt32(SessionKeys.UserId);
        var role = session.GetString(SessionKeys.Role);
        if (id is null || string.IsNullOrWhiteSpace(role))
        {
            context.Result = new UnauthorizedObjectResult(new { message = "Please log in first." });
            return;
        }
        if (RequiredRole is not null && !string.Equals(role, RequiredRole, StringComparison.Ordinal))
        {
            context.Result = new ObjectResult(new { message = "You do not have permission for this operation." }) { StatusCode = 403 };
            return;
        }
        await next();
    }
}
