namespace FunClub.Api.Models;
public class Enrollment
{
    public int EnrollmentId { get; set; }
    public int ParticipantId { get; set; }
    public User? Participant { get; set; }
    public int EventId { get; set; }
    public Event? Event { get; set; }
    public DateTime EnrollmentDate { get; set; } = DateTime.UtcNow;
}