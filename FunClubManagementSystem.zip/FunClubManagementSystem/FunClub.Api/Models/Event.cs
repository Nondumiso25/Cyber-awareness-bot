using System.ComponentModel.DataAnnotations;
namespace FunClub.Api.Models;
public class Event
{
    public int EventId { get; set; }
    [Required, MaxLength(120)] public string EventName { get; set; } = "";
    public DateOnly EventDate { get; set; }
    public TimeOnly StartTime { get; set; }
    [Required, MaxLength(200)] public string Venue { get; set; } = "";
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
    public int OrganiserId { get; set; }
    public User? Organiser { get; set; }
    public int MaxParticipants { get; set; } = 30;
    public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}