using FunClub.Api.Models;
using Microsoft.EntityFrameworkCore;
namespace FunClub.Api.Data;
public class FunClubDbContext(DbContextOptions<FunClubDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Enrollment> Enrollments => Set<Enrollment>();
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>().HasIndex(x => x.Email).IsUnique();
        modelBuilder.Entity<User>().Property(x => x.Role).HasDefaultValue("Participant");
        modelBuilder.Entity<Category>().HasIndex(x => x.CategoryName).IsUnique();
        modelBuilder.Entity<Enrollment>().HasIndex(x => new { x.ParticipantId, x.EventId }).IsUnique();
        modelBuilder.Entity<Enrollment>().HasOne(x => x.Participant).WithMany(x => x.Enrollments)
            .HasForeignKey(x => x.ParticipantId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<Enrollment>().HasOne(x => x.Event).WithMany(x => x.Enrollments)
            .HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<Event>().HasOne(x => x.Category).WithMany(x => x.Events)
            .HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Event>().HasOne(x => x.Organiser).WithMany(x => x.OrganisedEvents)
            .HasForeignKey(x => x.OrganiserId).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Event>().ToTable(t => t.HasCheckConstraint("CK_Event_MaxParticipants", "[MaxParticipants] > 0"));
    }
}