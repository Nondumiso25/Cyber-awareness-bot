using FunClub.Api.Data;
using FunClub.Api.DTOs;
using FunClub.Api.Infrastructure;
using FunClub.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace FunClub.Api.Controllers;
[ApiController, Route("api/events"), SessionAuthorize]
public class EventsController(FunClubDbContext db) : ControllerBase
{
    /// <summary>List scheduled events with category details.</summary>
    [HttpGet] public async Task<IActionResult> GetAll() => Ok(await db.Events.Include(e => e.Category).OrderBy(e => e.EventDate).ThenBy(e => e.StartTime).Select(e => new { e.EventId, e.EventName, e.EventDate, e.StartTime, e.Venue, e.CategoryId, Category = e.Category!.CategoryName, e.OrganiserId, e.MaxParticipants, Enrolled = e.Enrollments.Count }).ToListAsync());
    /// <summary>Get an event by ID.</summary>
    [HttpGet("{id:int}")] public async Task<IActionResult> Get(int id) { var e = await db.Events.Include(x => x.Category).Include(x => x.Enrollments).SingleOrDefaultAsync(x => x.EventId == id); return e is null ? NotFound() : Ok(new { e.EventId, e.EventName, e.EventDate, e.StartTime, e.Venue, e.CategoryId, Category = e.Category!.CategoryName, e.OrganiserId, e.MaxParticipants, Enrolled = e.Enrollments.Count }); }
    /// <summary>Create an event. Lecturer only.</summary>
    [HttpPost, SessionAuthorize("Lecturer")]
    public async Task<IActionResult> Create(EventRequest request)
    {
        if (!await db.Categories.AnyAsync(c => c.CategoryId == request.CategoryId)) return BadRequest(new { message = "Category does not exist." });
        var e = new Event { EventName = request.EventName.Trim(), EventDate = request.EventDate, StartTime = request.StartTime, Venue = request.Venue.Trim(), CategoryId = request.CategoryId, OrganiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value, MaxParticipants = request.MaxParticipants };
        db.Events.Add(e); await db.SaveChangesAsync(); return CreatedAtAction(nameof(Get), new { id = e.EventId }, e);
    }
    /// <summary>Update an event. Lecturer only; capacity cannot be lower than current enrolment.</summary>
    [HttpPut("{id:int}"), SessionAuthorize("Lecturer")]
    public async Task<IActionResult> Update(int id, EventRequest request)
    {
        var e = await db.Events.Include(x => x.Enrollments).SingleOrDefaultAsync(x => x.EventId == id); if (e is null) return NotFound();
        if (!await db.Categories.AnyAsync(c => c.CategoryId == request.CategoryId)) return BadRequest(new { message = "Category does not exist." });
        if (request.MaxParticipants < e.Enrollments.Count) return Conflict(new { message = "Capacity cannot be lower than current enrolment." });
        e.EventName = request.EventName.Trim(); e.EventDate = request.EventDate; e.StartTime = request.StartTime; e.Venue = request.Venue.Trim(); e.CategoryId = request.CategoryId; e.MaxParticipants = request.MaxParticipants;
        await db.SaveChangesAsync(); return Ok(e);
    }
    /// <summary>Delete an event. Lecturer only.</summary>
    [HttpDelete("{id:int}"), SessionAuthorize("Lecturer")]
    public async Task<IActionResult> Delete(int id) { var e = await db.Events.FindAsync(id); if (e is null) return NotFound(); db.Events.Remove(e); await db.SaveChangesAsync(); return NoContent(); }
}