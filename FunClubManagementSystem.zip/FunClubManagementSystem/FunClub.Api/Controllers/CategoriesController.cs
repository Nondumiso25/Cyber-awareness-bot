using FunClub.Api.Data;
using FunClub.Api.DTOs;
using FunClub.Api.Infrastructure;
using FunClub.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace FunClub.Api.Controllers;
[ApiController, Route("api/categories"), SessionAuthorize]
public class CategoriesController(FunClubDbContext db) : ControllerBase
{
    /// <summary>List all categories. Requires login.</summary>
    [HttpGet] public async Task<IActionResult> GetAll() => Ok(await db.Categories.OrderBy(c => c.CategoryName).ToListAsync());
    /// <summary>Get a category by ID.</summary>
    [HttpGet("{id:int}")] public async Task<IActionResult> Get(int id) { var c = await db.Categories.FindAsync(id); return c is null ? NotFound() : Ok(c); }
    /// <summary>Create a category. Lecturer only.</summary>
    [HttpPost, SessionAuthorize("Lecturer")]
    public async Task<IActionResult> Create(CategoryRequest request)
    {
        if (await db.Categories.AnyAsync(c => c.CategoryName == request.CategoryName.Trim())) return Conflict(new { message = "Category already exists." });
        var c = new Category { CategoryName = request.CategoryName.Trim(), Description = request.Description };
        db.Categories.Add(c); await db.SaveChangesAsync(); return CreatedAtAction(nameof(Get), new { id = c.CategoryId }, c);
    }
    /// <summary>Update a category. Lecturer only.</summary>
    [HttpPut("{id:int}"), SessionAuthorize("Lecturer")]
    public async Task<IActionResult> Update(int id, CategoryRequest request)
    {
        var c = await db.Categories.FindAsync(id); if (c is null) return NotFound();
        if (await db.Categories.AnyAsync(x => x.CategoryId != id && x.CategoryName == request.CategoryName.Trim())) return Conflict(new { message = "Category already exists." });
        c.CategoryName = request.CategoryName.Trim(); c.Description = request.Description;
        await db.SaveChangesAsync(); return Ok(c);
    }
    /// <summary>Delete a category. Categories used by events cannot be deleted.</summary>
    [HttpDelete("{id:int}"), SessionAuthorize("Lecturer")]
    public async Task<IActionResult> Delete(int id)
    {
        var c = await db.Categories.FindAsync(id); if (c is null) return NotFound();
        if (await db.Events.AnyAsync(e => e.CategoryId == id)) return Conflict(new { message = "Delete or reassign related events first." });
        db.Categories.Remove(c); await db.SaveChangesAsync(); return NoContent();
    }
}