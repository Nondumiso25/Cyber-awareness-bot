using FunClub.Api.Data;
using FunClub.Api.DTOs;
using FunClub.Api.Infrastructure;
using FunClub.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace FunClub.Api.Controllers;
[ApiController, Route("api/enrollments"), SessionAuthorize]
public class EnrollmentsController(FunClubDbContext db) : ControllerBase
{
    /// <summary>Enrol the logged-in Participant in an event.</summary>
    [HttpPost, SessionAuthorize("Participant")]
    public async Task<IActionResult> Enrol([FromBody] int eventId)
    {
        var participantId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
        var ev = await db.Events.Include(e => e.Enrollments).SingleOrDefaultAsync(e => e.EventId == eventId);
        if (ev is null) return NotFound(new { message = "Event not found." });
        if (await db.Enrollments.AnyAsync(x => x.ParticipantId == participantId && x.EventId == eventId)) return Conflict(new { message = "Already enrolled in this event." });
        if (ev.Enrollments.Count >= ev.MaxParticipants) return Conflict(new { message = "Event is at capacity." });
        var enrollment = new Enrollment { ParticipantId = participantId, EventId = eventId, EnrollmentDate = DateTime.UtcNow };
        db.Enrollments.Add(enrollment);
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateException) { return Conflict(new { message = "Could not enrol; check for duplicate enrolment or capacity." }); }
        return Created("", new { enrollment.EnrollmentId, enrollment.EventId, enrollment.EnrollmentDate });
    }
    /// <summary>Cancel your own enrolment.</summary>
    [HttpDelete("{id:int}"), SessionAuthorize("Participant")]
    public async Task<IActionResult> Cancel(int id)
    {
        var participantId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
        var e = await db.Enrollments.SingleOrDefaultAsync(x => x.EnrollmentId == id && x.ParticipantId == participantId);
        if (e is null) return NotFound(new { message = "Enrolment not found for your account." });
        db.Enrollments.Remove(e); await db.SaveChangesAsync(); return NoContent();
    }
    /// <summary>Show the current Participant's activity count and full schedule.</summary>
    [HttpGet("my"), SessionAuthorize("Participant")]
    public async Task<IActionResult> MyActivities()
    {
        var id = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
        var user = await db.Users.SingleAsync(u => u.UserId == id);
        var activities = await db.Enrollments.Where(x => x.ParticipantId == id).Include(x => x.Event).ThenInclude(e => e!.Category)
            .OrderBy(x => x.Event!.EventDate).Select(x => new ActivitySummary(x.EventId, x.Event!.EventName, x.Event.Category!.CategoryName, x.Event.EventDate, x.Event.StartTime, x.Event.Venue)).ToListAsync();
        return Ok(new ParticipantSummary($"{user.FirstName} {user.Surname}", activities.Count, activities));
    }
    /// <summary>Return the number of current enrolments for the logged-in Participant.</summary>
    [HttpGet("my/count"), SessionAuthorize("Participant")]
    public async Task<IActionResult> MyCount()
    {
        var id = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
        return Ok(new { numberOfActivities = await db.Enrollments.CountAsync(x => x.ParticipantId == id) });
    }
}