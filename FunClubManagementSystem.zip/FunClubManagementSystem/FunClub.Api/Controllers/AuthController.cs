using FunClub.Api.Data;
using FunClub.Api.DTOs;
using FunClub.Api.Infrastructure;
using FunClub.Api.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace FunClub.Api.Controllers;
[ApiController, Route("api/auth")]
public class AuthController(FunClubDbContext db, IPasswordHasher<User> hasher) : ControllerBase
{
    /// <summary>Register a Participant account. Lecturer creation is restricted to trusted administration.</summary>
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(u => u.Email == email)) return Conflict(new { message = "Email is already registered." });
        var user = new User { FirstName = request.FirstName.Trim(), Surname = request.Surname.Trim(), Email = email, Role = "Participant" };
        user.PasswordHash = hasher.HashPassword(user, request.Password);
        db.Users.Add(user);
        await db.SaveChangesAsync();
        return Created("", new UserResponse(user.UserId, user.FirstName, user.Surname, user.Email, user.Role));
    }
    /// <summary>Verify credentials and establish an ASP.NET Core session.</summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var user = await db.Users.SingleOrDefaultAsync(u => u.Email == request.Email.Trim().ToLowerInvariant());
        if (user is null || hasher.VerifyHashedPassword(user, user.PasswordHash, request.Password) == PasswordVerificationResult.Failed)
            return Unauthorized(new { message = "Invalid email or password." });
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.UserId);
        HttpContext.Session.SetString(SessionKeys.Role, user.Role);
        HttpContext.Session.SetString(SessionKeys.Name, $"{user.FirstName} {user.Surname}");
        return Ok(new UserResponse(user.UserId, user.FirstName, user.Surname, user.Email, user.Role));
    }
    /// <summary>End the current session.</summary>
    [HttpPost("logout"), SessionAuthorize]
    public IActionResult Logout() { HttpContext.Session.Clear(); return NoContent(); }
}