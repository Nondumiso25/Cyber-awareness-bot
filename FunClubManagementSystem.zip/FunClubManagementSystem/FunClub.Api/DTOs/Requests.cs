using System.ComponentModel.DataAnnotations;
namespace FunClub.Api.DTOs;
public class RegisterRequest
{
    [Required, MaxLength(80)] public string FirstName { get; set; } = "";
    [Required, MaxLength(80)] public string Surname { get; set; } = "";
    [Required, EmailAddress, MaxLength(256)] public string Email { get; set; } = "";
    [Required, MinLength(8)] public string Password { get; set; } = "";
    // Public registration intentionally cannot create Lecturers. Use a trusted admin process to create lecturer accounts.
}
public class LoginRequest { [Required, EmailAddress] public string Email { get; set; } = ""; [Required] public string Password { get; set; } = ""; }
public record UserResponse(int UserId, string FirstName, string Surname, string Email, string Role);
public class CategoryRequest { [Required, MaxLength(80)] public string CategoryName { get; set; } = ""; [MaxLength(500)] public string? Description { get; set; } }
public class EventRequest
{
    [Required, MaxLength(120)] public string EventName { get; set; } = "";
    public DateOnly EventDate { get; set; }
    public TimeOnly StartTime { get; set; }
    [Required, MaxLength(200)] public string Venue { get; set; } = "";
    [Range(1, 100000)] public int MaxParticipants { get; set; } = 30;
    [Range(1, int.MaxValue)] public int CategoryId { get; set; }
}
public record ActivitySummary(int EventId, string EventName, string Category, DateOnly Date, TimeOnly StartTime, string Venue);
public record ParticipantSummary(string Participant, int NumberOfActivities, IReadOnlyList<ActivitySummary> Activities);
