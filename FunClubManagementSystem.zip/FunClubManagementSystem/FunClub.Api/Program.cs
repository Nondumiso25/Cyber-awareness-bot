using FunClub.Api.Data;
using FunClub.Api.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new() { Title = "Fun Club Management API", Version = "v1",
        Description = "Manage Fun Club activities, categories, participants and enrolments." });
});
builder.Services.AddDbContext<FunClubDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("FunClub")
        ?? "Server=(localdb)\\MSSQLLocalDB;Database=FunClubDb;Trusted_Connection=True;TrustServerCertificate=True"));
builder.Services.AddSingleton<IPasswordHasher<User>, PasswordHasher<User>>();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.IdleTimeout = TimeSpan.FromMinutes(30);
});
var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();
app.UseSession();
app.MapControllers();

// For a convenient first run. In production, use EF migrations and a controlled seed process.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<FunClubDbContext>();
    if (app.Configuration.GetValue<bool>("ApplyDatabaseOnStartup"))
        await db.Database.MigrateAsync();
    if (!await db.Categories.AnyAsync())
    {
        db.Categories.AddRange(
            new Category { CategoryName = "Chess", Description = "Chess activities and tournaments" },
            new Category { CategoryName = "Football", Description = "Football matches and practice" },
            new Category { CategoryName = "Singing", Description = "Singing and choir activities" },
            new Category { CategoryName = "Spelling Bee", Description = "Spelling competitions" },
            new Category { CategoryName = "Swimming", Description = "Swimming activities" });
        await db.SaveChangesAsync();
    }
}
app.Run();
public partial class Program { }
