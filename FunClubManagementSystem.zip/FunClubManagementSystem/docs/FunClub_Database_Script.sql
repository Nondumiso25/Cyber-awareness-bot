-- Fun Club Management System database schema and sample data
-- SQL Server. Password hashes below are placeholders; register users through the API for real password hashes.
IF DB_ID(N'FunClubDb') IS NULL CREATE DATABASE FunClubDb;
GO
USE FunClubDb;
GO
IF OBJECT_ID('dbo.Enrollments','U') IS NOT NULL DROP TABLE dbo.Enrollments;
IF OBJECT_ID('dbo.Events','U') IS NOT NULL DROP TABLE dbo.Events;
IF OBJECT_ID('dbo.Categories','U') IS NOT NULL DROP TABLE dbo.Categories;
IF OBJECT_ID('dbo.Users','U') IS NOT NULL DROP TABLE dbo.Users;
GO
CREATE TABLE dbo.Users (
 UserId INT IDENTITY(1,1) PRIMARY KEY,
 FirstName NVARCHAR(80) NOT NULL, Surname NVARCHAR(80) NOT NULL,
 Email NVARCHAR(256) NOT NULL UNIQUE, PasswordHash NVARCHAR(MAX) NOT NULL,
 Role NVARCHAR(20) NOT NULL CONSTRAINT DF_Users_Role DEFAULT 'Participant',
 CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_Users_Role CHECK (Role IN ('Lecturer','Participant'))
);
CREATE TABLE dbo.Categories (
 CategoryId INT IDENTITY(1,1) PRIMARY KEY,
 CategoryName NVARCHAR(80) NOT NULL UNIQUE, Description NVARCHAR(500) NULL
);
CREATE TABLE dbo.Events (
 EventId INT IDENTITY(1,1) PRIMARY KEY,
 EventName NVARCHAR(120) NOT NULL, EventDate DATE NOT NULL, StartTime TIME NOT NULL,
 Venue NVARCHAR(200) NOT NULL, CategoryId INT NOT NULL, OrganiserId INT NOT NULL,
 MaxParticipants INT NOT NULL,
 CONSTRAINT CK_Event_MaxParticipants CHECK (MaxParticipants > 0),
 CONSTRAINT FK_Events_Categories FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(CategoryId),
 CONSTRAINT FK_Events_Organiser FOREIGN KEY (OrganiserId) REFERENCES dbo.Users(UserId)
);
CREATE TABLE dbo.Enrollments (
 EnrollmentId INT IDENTITY(1,1) PRIMARY KEY, ParticipantId INT NOT NULL, EventId INT NOT NULL,
 EnrollmentDate DATETIME2 NOT NULL CONSTRAINT DF_Enrollments_Date DEFAULT SYSUTCDATETIME(),
 CONSTRAINT UQ_Enrollments_Participant_Event UNIQUE (ParticipantId, EventId),
 CONSTRAINT FK_Enrollments_Participant FOREIGN KEY (ParticipantId) REFERENCES dbo.Users(UserId),
 CONSTRAINT FK_Enrollments_Event FOREIGN KEY (EventId) REFERENCES dbo.Events(EventId)
);
GO
INSERT INTO dbo.Users (FirstName,Surname,Email,PasswordHash,Role) VALUES
('Amina','Dlamini','lecturer1@funclub.local','REPLACE_WITH_HASH_FROM_API','Lecturer'),
('Peter','Mokoena','lecturer2@funclub.local','REPLACE_WITH_HASH_FROM_API','Lecturer'),
('Lebo','Nkosi','participant1@funclub.local','REPLACE_WITH_HASH_FROM_API','Participant'),
('Thandi','Zulu','participant2@funclub.local','REPLACE_WITH_HASH_FROM_API','Participant');
INSERT INTO dbo.Categories (CategoryName,Description) VALUES
('Chess','Chess activities and tournaments'),('Football','Football matches and practice'),
('Singing','Singing and choir activities'),('Spelling Bee','Spelling competitions'),('Swimming','Swimming activities');
INSERT INTO dbo.Events (EventName,EventDate,StartTime,Venue,CategoryId,OrganiserId,MaxParticipants) VALUES
('Chess Challenge','2026-10-03','10:00','Library',1,1,20),
('Football Friendly','2026-10-05','14:00','Sports Field',2,1,30),
('Choir Practice','2026-10-07','15:00','Music Room',3,2,25);
INSERT INTO dbo.Enrollments (ParticipantId,EventId) VALUES (3,1),(3,2),(4,3);
GO
-- Verification: participant schedule
SELECT u.FirstName + ' ' + u.Surname AS Participant, e.EventName, c.CategoryName,
       e.EventDate, e.StartTime, e.Venue
FROM dbo.Enrollments en
JOIN dbo.Users u ON u.UserId=en.ParticipantId
JOIN dbo.Events e ON e.EventId=en.EventId
JOIN dbo.Categories c ON c.CategoryId=e.CategoryId
ORDER BY Participant,e.EventDate;
-- Verification: participant activity counts
SELECT u.UserId, u.FirstName + ' ' + u.Surname AS Participant, COUNT(en.EnrollmentId) AS NumberOfActivities
FROM dbo.Users u LEFT JOIN dbo.Enrollments en ON en.ParticipantId=u.UserId
WHERE u.Role='Participant'
GROUP BY u.UserId,u.FirstName,u.Surname;
GO