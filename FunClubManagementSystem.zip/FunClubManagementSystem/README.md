# Fun Club Management System

ASP.NET Core 8 Web API, EF Core, SQL Server, session-based authentication, role restrictions, Swagger, unit tests and GitHub Actions, based on the supplied assignment.

## Requirements
- .NET 8 SDK
- SQL Server / SQL Server LocalDB
- Optional: Visual Studio 2022 or VS Code

## Configure and run
1. Open `FunClub.sln`.
2. Update `FunClub.Api/appsettings.json` connection string for your SQL Server.
3. From the repository root:
   ```bash
   dotnet restore FunClub.sln
   dotnet tool install --global dotnet-ef --version 8.0.11
   dotnet ef migrations add InitialCreate --project FunClub.Api
   dotnet ef database update --project FunClub.Api
   dotnet run --project FunClub.Api
   ```
4. Open the Swagger URL printed in the console, usually `/swagger`.
5. Register a Participant at `POST /api/auth/register`, then log in at `POST /api/auth/login`. The session cookie is used for later calls. Use the same browser or a client that preserves cookies.
6. To test Lecturer operations, create a Lecturer account through a trusted administrator process. Public registration deliberately creates Participants only. For local development, you may manually add a Lecturer through SQL Server with a valid ASP.NET Identity `PasswordHasher<User>` hash; never expose unrestricted role selection publicly.
7. `POST /api/enrollments` expects a JSON integer event ID, e.g. `1`. Use `GET /api/enrollments/my` and `/api/enrollments/my/count` to view your schedule.

## API summary
| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/register` | Public; Participant only |
| POST | `/api/auth/login` | Public |
| POST | `/api/auth/logout` | Logged in |
| GET | `/api/categories` and `/api/categories/{id}` | Logged in |
| POST/PUT/DELETE | `/api/categories` and `/api/categories/{id}` | Lecturer |
| GET | `/api/events` and `/api/events/{id}` | Logged in |
| POST/PUT/DELETE | `/api/events` and `/api/events/{id}` | Lecturer |
| POST | `/api/enrollments` | Participant |
| DELETE | `/api/enrollments/{id}` | Participant; own enrolment only |
| GET | `/api/enrollments/my` | Participant |
| GET | `/api/enrollments/my/count` | Participant |

## Tests
```bash
dotnet test FunClub.sln
```

## SQL script
`docs/FunClub_Database_Script.sql` creates the schema, sample records, and verification queries. It is a destructive reset script for these four tables: review it before running on any database with data.

## Notes
- Passwords are hashed with ASP.NET Core's `PasswordHasher<User>` and are never returned in ordinary responses.
- Public registration intentionally ignores role selection and always creates Participants.
- Session state is stored in the server-side distributed memory cache. For production, configure a durable distributed cache, HTTPS, secure cookie settings and CSRF protections as appropriate.
- This starter includes EF Core Code-First instructions rather than a generated migration; run the migration commands above after configuring the connection string.
- Capacity checks are implemented at application level; high-concurrency deployments should use a transaction/locking strategy to prevent race conditions.
