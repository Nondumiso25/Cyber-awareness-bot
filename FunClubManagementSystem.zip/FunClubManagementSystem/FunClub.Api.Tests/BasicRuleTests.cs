using FunClub.Api.Data;
using FunClub.Api.Models;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace FunClub.Api.Tests;
public class BasicRuleTests
{
    private static FunClubDbContext CreateDb()
    {
        var options = new DbContextOptionsBuilder<FunClubDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        return new FunClubDbContext(options);
    }
    [Fact]
    public async Task UserAndCategoryCanBeStored()
    {
        await using var db = CreateDb();
        db.Users.Add(new User { FirstName = "Test", Surname = "Participant", Email = "test@example.com", PasswordHash = "hashed", Role = "Participant" });
        db.Categories.Add(new Category { CategoryName = "Chess", Description = "Board games" });
        await db.SaveChangesAsync();
        Assert.Equal(1, await db.Users.CountAsync());
        Assert.Equal("Chess", (await db.Categories.SingleAsync()).CategoryName);
    }
    [Fact]
    public async Task EnrolmentLinksParticipantAndEvent()
    {
        await using var db = CreateDb();
        var user = new User { FirstName = "A", Surname = "Student", Email = "a@example.com", PasswordHash = "hashed", Role = "Participant" };
        var lecturer = new User { FirstName = "L", Surname = "Teacher", Email = "l@example.com", PasswordHash = "hashed", Role = "Lecturer" };
        var cat = new Category { CategoryName = "Chess" };
        db.AddRange(user, lecturer, cat);
        await db.SaveChangesAsync();
        var ev = new FunClub.Api.Models.Event { EventName = "Chess Challenge", EventDate = new DateOnly(2026, 10, 3), StartTime = new TimeOnly(10, 0), Venue = "Library", CategoryId = cat.CategoryId, OrganiserId = lecturer.UserId, MaxParticipants = 5 };
        db.Events.Add(ev); await db.SaveChangesAsync();
        db.Enrollments.Add(new Enrollment { ParticipantId = user.UserId, EventId = ev.EventId });
        await db.SaveChangesAsync();
        Assert.Equal(1, await db.Enrollments.CountAsync(x => x.ParticipantId == user.UserId));
    }
}