INSERT INTO ROUTE (event_id, description, map_link,route_id) VALUES
(1, 'Starts at Union Buildings, loops through CBD.', 'https://maps.example.com/pretoria-marathon',1),
(2, 'Mountain loop from Giants Castle camp.', 'https://maps.example.com/drakensberg-trail',2),
(3, 'Seapoint Promenade out-and-back.', 'https://maps.example.com/ct-night-run',3);