INSERT INTO CATEGORY (event_id, name, distance, type,category_id) VALUES
(1, 'Full Marathon', '42.2km', 'Road Running',1),
(1, 'Half Marathon', '21.1km', 'Road Running',2),
(2, 'Ultra Trail', '50km', 'Trail Running',3),
(3, 'Fun Run', '5km', 'Night Run',4);