INSERT INTO EVENT (name, date, location, description, organizer_id,event_id) VALUES
('Pretoria City Marathon', '2026-10-18', 'Pretoria, Gauteng', 'Annual 42km, 21km and 10km road race through the city.', 1,1),
('Drakensberg Trail Challenge', '2026-11-15', 'Drakensberg, KZN', 'Tough off-road trail running event with high altitude routes.', 2,2),
('Cape Town Night Run', '2026-12-05', 'Cape Town, Western Cape', '5km fun night run with LED lights and music.', 1,3);