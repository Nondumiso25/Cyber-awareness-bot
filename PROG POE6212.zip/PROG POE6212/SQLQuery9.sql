CREATE TABLE ROUTE (
    route_id INT PRIMARY KEY ,
    event_id INT UNIQUE NOT NULL, 
    description TEXT,
    map_link VARCHAR(2048), 
    FOREIGN KEY (event_id) REFERENCES EVENT(event_id)
);