INSERT INTO WEATHER_INFO (event_id, date, forecast, temperature, conditions, weather_id) VALUES
(1, '2026-10-18', 'Sunny', '22�C', 'Clear, light wind',1),
(2, '2026-11-15', 'Partly Cloudy', '15�C', 'Mist in morning, cool',2),
(3, '2026-12-05', 'Clear Night', '18�C', 'Cool evening breeze',3);