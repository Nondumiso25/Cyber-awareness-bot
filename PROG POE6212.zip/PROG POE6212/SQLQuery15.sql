INSERT INTO PARTICIPANT_EVENT (participant_id, event_id, registration_date, result) VALUES
(1, 1, '2026-09-01', 'Pending'),
(1, 3, '2026-09-02', 'Pending'),
(2, 1, '2026-09-01', 'Pending'),
(2, 2, '2026-09-03', 'Pending');