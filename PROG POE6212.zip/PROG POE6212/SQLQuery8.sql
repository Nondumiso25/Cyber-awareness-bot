CREATE TABLE PERFORMANCE_HISTORY (
    history_id INT PRIMARY KEY ,
    participant_id INT NOT NULL,
    event_id INT NOT NULL, 
    date DATE NOT NULL,
    performance_metric VARCHAR(255), 
    FOREIGN KEY (participant_id) REFERENCES PARTICIPANT(participant_id),
    FOREIGN KEY (event_id) REFERENCES EVENT(event_id)
);