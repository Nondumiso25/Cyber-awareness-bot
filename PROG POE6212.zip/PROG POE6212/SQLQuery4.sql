CREATE TABLE EVENT (
    event_id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    description TEXT,
    organizer_id INT NOT NULL,
    CONSTRAINT fk_event_organizer
        FOREIGN KEY (organizer_id)
        REFERENCES EVENT_ORGANIZER(organizer_id));