INSERT INTO PERFORMANCE_HISTORY (participant_id, event_id, date, performance_metric,history_id) VALUES
(1, 1, '2025-10-20', 'Finish Time: 03:45:10, Rank: 45th',1),
(2, 1, '2025-10-20', 'Finish Time: 04:10:05, Rank: 112th',2);
