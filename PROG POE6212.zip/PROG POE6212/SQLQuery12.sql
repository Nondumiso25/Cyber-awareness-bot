INSERT INTO EVENT_ORGANIZER (organizer_id, name, email, password) VALUES
(1, 'Sarah Jenkins', 'sarah.j@runevents.co.za', 'hashed_pass_123'),
(2, 'David Moyo', 'david.m@trailchamps.com', 'hashed_pass_456');