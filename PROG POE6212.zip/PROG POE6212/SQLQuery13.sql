INSERT INTO PARTICIPANT (name,email,password,participant_id) VALUES
('Thabo Nkosi', 'thabo.nkosi@gmail.com', 'hashed_pass_789',1),
('Lisa van Wyk', 'lisa.vanwyk@gmail.com', 'hashed_pass_012',2);