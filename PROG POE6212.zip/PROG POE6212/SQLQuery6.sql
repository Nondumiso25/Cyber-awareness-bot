CREATE TABLE CATEGORY (
    category_id INT PRIMARY KEY ,
    event_id INT NOT NULL, 
    name VARCHAR(255) NOT NULL,
    distance VARCHAR(50),
    type VARCHAR(100),
    FOREIGN KEY (event_id) REFERENCES EVENT(event_id)
);