CREATE TABLE PARTICIPANT_EVENT (
    participant_id INT NOT NULL,
    event_id INT NOT NULL,
    registration_date DATE NOT NULL,
    result VARCHAR(255), 
    PRIMARY KEY (participant_id, event_id),
    FOREIGN KEY (participant_id) REFERENCES PARTICIPANT(participant_id),
    FOREIGN KEY (event_id) REFERENCES EVENT(event_id)
);