CREATE TABLE WEATHER_INFO (
    weather_id INT PRIMARY KEY ,
    event_id INT UNIQUE NOT NULL, 
    date DATE NOT NULL,
    forecast VARCHAR(255),
    temperature VARCHAR(50),
    conditions VARCHAR(255),
    FOREIGN KEY (event_id) REFERENCES EVENT(event_id)
);