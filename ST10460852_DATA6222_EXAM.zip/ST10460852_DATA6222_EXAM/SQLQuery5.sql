SELECT 
v.VenueID,
v.VenueName,
v.VenueAddress,
CASE 
WHEN EXISTS ( 
SELECT 1 
FROM dbo.BOOKING AS r
WHERE r.VenueID = v.VenueID
)
THEN 'BOOKINGs exist'
ELSE ' No BOOKINGs exist'
END AS [BOOKING STATUS]
FROM dbo.VENUE AS v 
ORDER BY v.VenueID;
