


-- ==========================================
-- Create CLIENT table
-- ==========================================
CREATE TABLE CLIENT (
    ClientID VARCHAR(6) PRIMARY KEY,
    ClientFullName VARCHAR(20) NOT NULL,
    ClientContact VARCHAR(15) NOT NULL
);

-- ==========================================
-- Populate CLIENT table
-- ==========================================
INSERT INTO CLIENT (ClientID, ClientFullName, ClientContact)
VALUES
('111222', 'Lindiwe Mokoena', '072 4567 891'),
('222333', 'Mark Peterson', '083 9123 456'),
('333444', 'Ayanda Dlamini', '074 6789 321'),
('444555', 'Sipho Khumalo', '071 3456 789'),
('555666', 'Rachel Adams', '082 9876 543');

-- ==========================================
-- Create VENUE table
-- ==========================================
CREATE TABLE VENUE (
    VenueID VARCHAR(5) PRIMARY KEY,
    VenueName VARCHAR(25) NOT NULL,
    VenueAddress VARCHAR(30) NOT NULL
);

-- ==========================================
-- Populate VENUE table
-- ==========================================
INSERT INTO VENUE (VenueID, VenueName, VenueAddress)
VALUES
('V0001', 'Grand Hall', '45 Summit Road, Johannesburg'),
('V0002', 'City Convention Centre', '10 Market Street, Durban'),
('V0003', 'Riverside Pavilion', '88 River Road, Pretoria'),
('V0004', 'Coastal Conference Hall', '12 Beach Avenue, Gqeberha'),
('V0005', 'Mountain View Centre', '5 Peak Drive, Cape Town');

-- ==========================================
-- Create BOOKING table
-- ==========================================
CREATE TABLE BOOKING (
    BookingID VARCHAR(6) PRIMARY KEY,
    ClientID VARCHAR(6) NOT NULL,
    VenueID VARCHAR(5) NOT NULL,
    EventStartDate DATE NOT NULL,
    EventEndDate DATE NOT NULL,
    NumberOfAttendees INT NOT NULL,
    CONSTRAINT FK_Booking_Client FOREIGN KEY (ClientID) REFERENCES CLIENT(ClientID),
    CONSTRAINT FK_Booking_Venue FOREIGN KEY (VenueID) REFERENCES VENUE(VenueID)
);

-- ==========================================
-- Populate BOOKING table
-- ==========================================
INSERT INTO BOOKING (BookingID, ClientID, VenueID, EventStartDate, EventEndDate, NumberOfAttendees)
VALUES
('B00007', '111222', 'V0001', '2026-09-30', '2025-10-01', 120),
('B00005', '222333', 'V0005', '2026-09-29', '2025-10-02', 40),
('B00006', '222333', 'V0004', '2026-10-01', '2026-10-07', 200),
('B00002', '444555', 'V0002', '2026-09-28', '2026-10-01', 150),
('B00003', '555666', 'V0001', '2026-09-29', '2026-10-04', 300),
('B00001', '111222', 'V0002', '2026-09-20', '2026-09-30', 80),
('B00004', '222333', 'V0004', '2026-09-29', '2026-10-01', 60);

-- ==========================================
-- Verify table contents
-- ==========================================
SELECT * FROM CLIENT;
SELECT * FROM VENUE;
SELECT * FROM BOOKING;