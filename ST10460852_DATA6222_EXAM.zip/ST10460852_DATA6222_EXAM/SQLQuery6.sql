SELECT 
v.VenueName,
SUM(r.NumberOfAttendees) AS [ TOAL ATTENDEES]
FROM dbo.VENUE AS v 
LEFT JOIN dbo.BOOKING AS r
ON v.VenueID = r.VenueID
GROUP BY v.VenueID, v.VenueName
Order BY SUM ( r.NumberOfAttendees) DESC;