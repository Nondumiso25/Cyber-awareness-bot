CREATE PROCEDURE dbo.FindBOOKINGs
@VenueID VARCHAR(5)
AS 
BEGIN
SET NOCOUNT ON;
SELECT
v.VenueName,
c.ClientFullName, 
c.ClientContact,
r.EventStartDate,
r.EventEndDate,
r.NumberOfAttendees,

FROM dbo.BOOKING AS r
INNER JOIN dbo.VENUE AS v 
ON r.VenueID = v.VenueID 
INNER JOIN dbo.CLIENT as c
on r.ClientID = c.ClientID
WHERE r.VenueID = @VenueID;
END;
