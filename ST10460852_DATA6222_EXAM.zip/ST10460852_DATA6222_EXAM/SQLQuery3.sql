CREATE VIEW dbo.LargeBOOKINGs
As 
SELECT
BookingID,
ClientID,
VenueID,
EventStartDate,
EventEndDate,
NumberOfAttendees,
FROM dbo.BOOKING
WHERE EventStartDate >= '2026-01-01'
AND EventEndDate <= '2027-01-01'
AND NumberOfAttendees >= 100;

SELECT 
FROM  dbo.BOOKING;



