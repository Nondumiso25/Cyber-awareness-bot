﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace chatbot
{

    public class QuizGame
    {
        private List<QuizQuestion> _questions;
        private Random _random;

        public QuizGame()
        {
            _random = new Random();
            _questions = GenerateCybersecurityQuestions();
        }

        private List<QuizQuestion> GenerateCybersecurityQuestions() =>
            
            new List<QuizQuestion>
            {
                new MultipleChoiceQuestion
                {
                    QuestionText = "What is phishing?",
                    Options = new List<string>
                    {
                        "A type of malware that encrypts your files.",
                        "An attempt to trick you into revealing personal information.",
                        "A method for securing network traffic.",
                        "Software that monitors your online activity."
                    },
                    CorrectOptionIndex = 1,
                    Explanation = "Phishing is a social engineering technique where attackers try to deceive individuals into revealing sensitive information, often through fake emails or websites."
                },
                new TrueFalseQuestion
                {
                    QuestionText = "It's safe to use the same password for all your online accounts.",
                    CorrectAnswer = false,
                    Explanation = "Using the same password for multiple accounts is highly risky. If one account is compromised, all others using that password become vulnerable. Use unique, strong passwords for each service."
                },
                new MultipleChoiceQuestion
                {
                    QuestionText = "Which of these is a strong password?",
                    Options = new List<string>
                    {
                        "password123",
                        "MyDogSpot!",
                        "P@$$w0rdS3cur3!",
                        "12345678"
                    },
                    CorrectOptionIndex = 2,
                    Explanation = "A strong password uses a mix of uppercase and lowercase letters, numbers, and symbols, and is sufficiently long. 'P@$$w0rdS3cur3!' meets these criteria better than the others."
                },
                new TrueFalseQuestion
                {
                    QuestionText = "Public Wi-Fi networks are always secure for sensitive transactions.",
                    CorrectAnswer = false,
                    Explanation = "Public Wi-Fi networks are often unsecured and can be easily monitored by attackers. Avoid conducting sensitive transactions (like online banking or shopping) on public Wi-Fi without a VPN."
                },
                new MultipleChoiceQuestion
                {
                    QuestionText = "What is social engineering in cybersecurity?",
                    Options

                }
            }
            }

            }
            



                
           







