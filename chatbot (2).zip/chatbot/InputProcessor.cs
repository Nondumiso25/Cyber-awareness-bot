﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace chatbot
{
    internal class InputProcessor
    {

        public class Program
        {
            private static DbManager? _dbManager;
            private static InputProcessor? _inputProcessor;

            static void Main(string[] args)
            {

                _dbManager = new DbManager("localhost", "CybersecurityTasksDB", "your_username", "your_password");
                _inputProcessor = new InputProcessor();

                WriteLine("Welcome to the Cybersecurity Task Assistant!");
                DisplayMenu();

                while (true)
                {
                    Write("\nEnter command: ");
                    string input = ReadLine().ToLowerInvariant().Trim();

                    if (input == "exit")
                    {
                        WriteLine("Exiting application. Goodbye!");
                        break;
                    }
                    else if (input == "menu")
                    {
                        DisplayMenu();
                    }
                    else
                    {
                        ProcessUserInput(input);
                    }
                }
            }

            static void DisplayMenu()
            {
                WriteLine("\n--- Menu ---");
                WriteLine("1. Add a new task (e.g., 'add task update password')");
                WriteLine("2. List all tasks (e.g., 'show tasks')");
                WriteLine("3. Complete a task (e.g., 'complete task 5')");
                WriteLine("4. Delete a task (e.g., 'delete task 3')");
                WriteLine("5. Set a reminder (e.g., 'remind me to check logs tomorrow at 10am')");
                WriteLine("Type 'menu' to see this menu again.");
                WriteLine("Type 'exit' to quit.");
            }

            static void ProcessUserInput(string input)
            {


                var intent = _inputProcessor.DetermineIntent(input);

                switch (intent.Type)
                {
                    case IntentType.AddTask:
                        HandleAddTask(input, intent.Keywords);
                        break;
                    case IntentType.AddReminder:
                        HandleAddReminder(input, intent.Keywords);
                        break;
                    case IntentType.ListTasks:
                        ListTasks();
                        break;
                    case IntentType.CompleteTask:
                        HandleCompleteTask(input);
                        break;
                    case IntentType.DeleteTask:
                        HandleDeleteTask(input);
                        break;
                    case IntentType.Unknown:
                    default:
                        WriteLine("I didn't quite understand that. Could you rephrase? Try 'menu' for options.");
                        break;
                }
            }



            static void HandleAddTask(string input, List<string> keywords)
            {
                Write("Enter task title (e.g., 'Update firewall rules'): ");
                string title = ReadLine();
                Write("Enter task description (optional): ");
                string description = ReadLine();

                DateTime? reminder = null;
                Write("Set a reminder date and time? (yyyy-MM-dd HH:mm, or leave blank): ");
                string reminderInput = ReadLine();
                if (DateTime.TryParse(reminderInput, out DateTime parsedReminder))
                {
                    reminder = parsedReminder;
                }

                Task newTask = new Task
                {
                    Title = title,
                    Description = description,
                    ReminderDateTime = reminder,
                    IsCompleted = false
                };

                try
                {
                    _dbManager.AddTask(newTask);
                    WriteLine("Task added successfully!");
                }
                catch (Exception ex)
                {
                    WriteLine($"Error adding task: {ex.Message}");
                }
            }

            static void HandleAddReminder(string input, List<string> keywords)
            {

                Write("What is the reminder for? (e.g., 'Update my password'): ");
                string title = ReadLine();
            }
        }

    }
}


