﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace chatbot
{
    
    public abstract class QuizQuestion
    {
        public string QuestionText { get; set; }
        public string Explanation { get; set; }

        public abstract bool CheckAnswer(string userAnswer);
        public abstract void DisplayQuestion();
    }

    public class MultipleChoiceQuestion : QuizQuestion
    {
        public List<string> Options { get; set; }
        public int CorrectOptionIndex { get; set; } 
        public override void DisplayQuestion()
        {
            WriteLine($"\nQuestion: {QuestionText}");
            for (int i = 0; i < Options.Count; i++)
            {
                WriteLine($"  {i + 1}. {Options[i]}");
            }
            Write("Your answer (enter number): ");
        }

        public override bool CheckAnswer(string userAnswer)
        {
            if (int.TryParse(userAnswer, out int userChoice) && userChoice > 0 && userChoice <= Options.Count)
            {
                return (userChoice - 1) == CorrectOptionIndex;
            }
            return false;
        }
    }

    public class TrueFalseQuestion : QuizQuestion
    {
        public bool CorrectAnswer { get; set; }

        public override void DisplayQuestion()
        {
            WriteLine($"\nQuestion: {QuestionText}");
            Write("Your answer (True/False): ");
        }

        public override bool CheckAnswer(string userAnswer)
        {
            if (bool.TryParse(userAnswer, out bool userChoice))
            {
                return userChoice == CorrectAnswer;
            }
            return false;
        }
    }
}

