﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chatbot
{
   
    public class ActivityLogEntry
    {
        public DateTime Timestamp { get; set; }
        public string ActionDescription { get; set; }

        public ActivityLogEntry(string description)
        {
            Timestamp = DateTime.Now;
            ActionDescription = description;
        }

        public override string ToString()
        {
            return $"{Timestamp:yyyy-MM-dd HH:mm:ss} - {ActionDescription}";
        }
    }
    public class ActivityLogger
    {
        private List<ActivityLogEntry> _logEntries;

        public ActivityLogger()
        {
            _logEntries = new List<ActivityLogEntry>();
        }

        public void LogAction(string description)
        {
            var entry = new ActivityLogEntry(description);
            _logEntries.Add(entry);
            
        }

        public void DisplayLog()
        {
            if (_logEntries.Count == 0)
            {
                Console.WriteLine("\nActivity Log is empty.");
                return;
            }

            Console.WriteLine("\n--- Activity Log ---");
            foreach (var entry in _logEntries)
            {
                Console.WriteLine(entry);
            }
            Console.WriteLine("--------------------");
        }
    }
}
