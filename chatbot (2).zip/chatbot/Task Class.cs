﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace chatbot
{
    

    public class Task
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public DateTime? ReminderDateTime { get; set; } 
        public bool IsCompleted { get; set; }

        public override string ToString()
        {
            string reminderInfo = ReminderDateTime.HasValue
                ? $" (Reminder: {ReminderDateTime.Value:yyyy-MM-dd HH:mm})"
                : "";
            string status = IsCompleted ? "[COMPLETED]" : "[PENDING]";
            return $"{status} - {Title}{reminderInfo}\n  Description: {Description}";
        }
    }
}
public class DbManager
{
    private readonly string _connectionString;

    public DbManager(string server, string database, string uid, string password)
    {
        _connectionString = $"SERVER={server};DATABASE={database};UID={uid};PASSWORD={password};";
    }

    private MySqlConnection GetConnection()
    {
        return new MySqlConnection(_connectionString);
    }

    
    public void AddTask(Task task)
    {
        using (var conn = GetConnection())
        {
            conn.Open();
            string query = "INSERT INTO Tasks (Title, Description, ReminderDateTime) VALUES (@Title, @Description, @ReminderDateTime)";
            using (var cmd = new MySqlCommand(query, conn))
            {
                MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("@Title", task.Title);
                cmd.Parameters.AddWithValue("@Description", task.Description);
                cmd.Parameters.AddWithValue("@ReminderDateTime", task.ReminderDateTime);
                cmd.ExecuteNonQuery();
            }
        }
    }

    
    public List<Task> GetAllTasks()
    {
        List<Task> tasks = new List<Task>();
        using (var conn = GetConnection())
        {
            conn.Open();
            string query = "SELECT Id, Title, Description, ReminderDateTime, IsCompleted FROM Tasks";
            using (MySqlCommand cmd = new MySqlCommand(query, conn))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    tasks.Add(new Task
                    {
                        Id = reader.GetInt32("Id"),
                        Title = reader.GetString("Title"),
                        Description = reader.GetString("Description"),
                        ReminderDateTime = reader.IsDBNull(reader.GetOrdinal("ReminderDateTime")) 
                        ? (DateTime?)null : reader.GetDateTime("ReminderDateTime"),
                        IsCompleted = reader.GetBoolean("IsCompleted")
                    });
                }
            }
        }
        return tasks;
    }

    
    public void DeleteTask(int taskId)
    {
        using (var conn = GetConnection())
        {
            conn.Open();
            string query = "DELETE FROM Tasks WHERE Id = @Id";
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Id", taskId);
                cmd.ExecuteNonQuery();
            }
        }
    }

   
    public void MarkTaskCompleted(int taskId, bool isCompleted)
    {
        using (var conn = GetConnection())
        {
            conn.Open();
            string query = "UPDATE Tasks SET IsCompleted = @IsCompleted WHERE Id = @Id";
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@IsCompleted", isCompleted);
                cmd.Parameters.AddWithValue("@Id", taskId);
                cmd.ExecuteNonQuery();
            }
        }
    }
}


