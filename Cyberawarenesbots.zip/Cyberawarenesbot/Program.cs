﻿namespace Cyberawarenesbot
{
    using System;
    using System.Media;
    using System.IO;
    using System.Threading;
    using static System.Console;

    internal class Program
    {

        public class CybersecurityBot
        {

            private static readonly string CyberSecurityLogo = @"
   _____           
  / ____|        
 | |    _   _ ___
 | |   | | | / __|  
 | |___| |_| \__ \ 
  \____|\__, |___/
         __/ |
        |___/  
";


            private static readonly string DecorativeBorder = "======================================================";

            public static void Main(string[] args)
            {
                Title = "Cybersecurity Awareness Bot";


                DisplayAsciiLogo();
                Thread.Sleep(2000);


                PlayVoiceGreeting();


                string userName = GetUserName();
                DisplayTextGreeting(userName);


                WriteLine("\nI'm ready to answer your cybersecurity questions, " + userName + ".");
                WriteLine("Press any key to exit the application.");
                ReadKey();
            }

            private static void DisplayAsciiLogo()
            {
                ForegroundColor = ConsoleColor.Green;
                WriteLine(CyberSecurityLogo);
                ForegroundColor = ConsoleColor.White;
                WriteLine("\nLoading Bot...");
            }

            private static void PlayVoiceGreeting()
            {
                string audioFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "welcome_greeting.wav");

                if (File.Exists(audioFilePath))
                {
                    try
                    {
                        SoundPlayer player = new SoundPlayer(audioFilePath);
                        player.PlaySync();
                        WriteLine("\n(Voice greeting played)");
                    }
                    catch (Exception ex)
                    {
                        WriteLine($"\nError playing voice greeting: {ex.Message}");
                        WriteLine("Ensure 'welcome_greeting.wav' is in the application directory.");
                    }
                }
                else
                {
                    WriteLine("\n(Voice greeting file 'welcome_greeting.wav' not found.)");
                    WriteLine("Ensure the WAV file is in the same directory as the executable.");
                }
            }

            private static string GetUserName()
            {
                WriteLine("\n" + DecorativeBorder);
                Write("Before we start, what's your name? ");
                string name = ReadLine();

                if (string.IsNullOrWhiteSpace(name))
                {
                    return "User";
                }
                return name;
            }

            private static void DisplayTextGreeting(string name)
            {
                WriteLine(DecorativeBorder);
                WriteLine($"Hello, {name}! Welcome to the Cybersecurity Awareness Bot.");
                WriteLine("I'm here to help you stay safe online by answering your questions.");
                WriteLine(DecorativeBorder);
            }
        }
    }
}
    

